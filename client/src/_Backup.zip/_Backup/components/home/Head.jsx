import { React, useEffect, useState } from 'react'
import { Link } from "react-router-dom";
import StarRateIcon from '@mui/icons-material/StarRate';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';

const Head = () => {
  return (
    <div className="headContainer" id="h">
        <div className="center-img">
          <h1>IT Department</h1>
          <h2>Grasso Tech</h2>
          <ArrowDropDownIcon className="scroll"/>
          <span className="bg"></span>
        </div>
        <div className="actions">
          <Link className="button" to="/programs"><span>Programs</span></Link>
          <Link className="button" to="/about"><span>About</span></Link>
          <Link className="button" to="/contact"><span>Contact</span></Link>
        </div>
    </div>
  )
}

export default Head