import React from 'react'
import Head from './Head';
import Header from '../Header';

export const Home = () => {
  let style = {background: "$primary-1"};
  return (
    <div className="homeContainer container" style={style}>
      <Header />
      <Head />
    </div>
  )
}

export default Home