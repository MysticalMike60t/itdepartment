import {React,useEffect,useState} from 'react'
import grassotechItLogo from '../images/grassotechItLogo.svg';
import { Link } from "react-router-dom";
import ReactSwitch from 'react-switch';

const Header = () => {
    return (
        <div className="headerContainer" id="header">
            <div className="logo">
                <Link to="/" className='logoLink'>
                    <img src={grassotechItLogo} alt="" />
                </Link>
            </div>
            <ul>
                <div>
                    <li><Link to="/" className="headerNavigationLink">Home</Link></li>
                    <li><Link to="/programs" className="headerNavigationLink">Programs</Link></li>
                    <li><Link to="/about" className="headerNavigationLink">About</Link></li>
                    <li><Link to="/contact" className="headerNavigationLink">Contact</Link></li>
                </div>
            </ul>
        </div>
        
        /*
        <div className="headerContainer">
            <ul>
                <li>
                    <a href="#">
                        <HomeIcon className="headerIcon" />
                        <div>
                            <h1>Home</h1>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <AccountTreeIcon className="headerIcon" />
                        <div>
                            <h1>Projects</h1>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <BookmarksIcon className="headerIcon" />
                        <div>
                            <h1>Boomarks</h1>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <Brightness6Icon className="headerIcon" />
                        <div>
                            <h1>Theme</h1>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
        */
    )
}

export default Header