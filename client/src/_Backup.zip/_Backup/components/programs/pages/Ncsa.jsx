import React from 'react';
import Header from '../../Header';

function Ncsa() {
  return (
    <div className="container">
        <Header />
    </div>
  );
}

export default Ncsa;
