import React from 'react';
import Header from '../../Header';

function Wd() {
  return (
    <div className="container">
        <Header />
    </div>
  );
}

export default Wd;
