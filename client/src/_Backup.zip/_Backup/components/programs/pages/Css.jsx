import React from 'react';
import Header from '../../Header';

function Css() {
  return (
    <div className="container">
        <Header />
    </div>
  );
}

export default Css;
