import React from 'react';
import Header from '../../Header';

function Isa() {
  return (
    <div className="container">
        <Header />
    </div>
  );
}

export default Isa;
