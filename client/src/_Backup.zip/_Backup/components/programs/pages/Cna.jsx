import React from 'react';
import Header from '../../Header';

function Cna() {
  return (
    <div className="container">
        <Header />
        <div className="page-wrapper">
          <div className="text-wrapper">
            <h1>What a Computer Network Architect does:</h1>
            <p>Computer network architects design and build data communication networks, including local area networks (LANs), wide area networks (WANs), and Intranets.</p>
          </div>
          <div className="sep"></div>
          <div className="text-wrapper">
            <h1>What a Computer Network Architect gets payed:</h1>
            <p>The median annual wage for computer network architects was $120,520 in May 2021.</p>
          </div>
          <div className="sep"></div>
          <div className="text-wrapper">
            <h1>Number of jobs as of 2021:</h1>
            <p>174,800</p>
          </div>
          <div className="sep"></div>
          <div className="text-wrapper">
            <h1>Requirements:</h1>
            <p>Computer network architects typically need a bachelor’s degree in a computer-related field and experience in a related occupation, such as network and computer systems administrators.</p>
          </div>
        </div>
    </div>
  );
}

export default Cna;
