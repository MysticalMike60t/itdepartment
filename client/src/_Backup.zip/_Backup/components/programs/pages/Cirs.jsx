import React from "react";
import { Link } from "react-router-dom";
import Header from "../../Header";

function Cirs() {
  return (
    <div className="container">
      <Header />
      <div className="page-wrapper">
        <div className="text-wrapper">
          <h1>What a Computer and Information Research Scientist does:</h1>
          <p>
            Computer and information research scientists design innovative uses
            for new and existing computing technology.
          </p>
        </div>
        <div className="sep"></div>
        <div className="text-wrapper">
          <h1>What type of things they do:</h1>
          <p>
            <b>
              <i>Programming<sup>[<Link to="/" className="i">i</Link>]</sup>:</i>
            </b>{" "}
            Some computer and information research scientists study and design
            new programming languages that are used to write software. New
            languages make software writing efficient by improving an existing
            language, such as Java, or by simplifying a specific aspect of
            programming, such as image processing.
            <br />
            <br />
            <b>
              <i>Robotics<sup>[<Link to="/" className="i">i</Link>]</sup>:</i>
            </b>{" "}
            These scientists study the development and application of robots.
            They explore how a machine can interact with the physical world. For
            example, they may create systems that control the robots or design
            robots to have features such as information processing or sensory
            feedback.
            <br />
            <br />
            Some computer and information research scientists work on
            multidisciplinary projects with electrical engineers, computer
            hardware engineers, and other specialists. For example, robotics
            specialists and engineers who design robots’ hardware may team up to
            test whether the robots complete tasks as intended.
          </p>
        </div>
        <div className="sep"></div>
        <div className="text-wrapper">
          <h1>
            What a Computer and Information Research Scientist gets payed:
          </h1>
          <p>
            The median annual wage for computer and information research
            scientists was $131,490 in May 2021.
          </p>
        </div>
        <div className="sep"></div>
        <div className="text-wrapper">
          <h1>Number of jobs as of 2021:</h1>
          <p>33,500</p>
        </div>
        <div className="sep"></div>
        <div className="text-wrapper">
          <h1>Requirements:</h1>
          <p>
            Computer and information research scientists typically need at least
            a master’s degree in computer science or a related field. In the
            federal government, a bachelor’s degree may be sufficient for some
            jobs.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Cirs;
