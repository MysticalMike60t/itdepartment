import React from 'react';
import Header from '../../Header';

function Cp() {
  return (
    <div className="container">
        <Header />
    </div>
  );
}

export default Cp;
