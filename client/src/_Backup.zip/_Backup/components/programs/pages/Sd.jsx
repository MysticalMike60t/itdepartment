import React from 'react';
import Header from '../../Header';

function Sd() {
  return (
    <div className="container">
        <Header />
    </div>
  );
}

export default Sd;
