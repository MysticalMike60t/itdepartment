import React from 'react'
import Header from '../Header';
import Cards from './Cards';

const Programs = () => {
  let style = {background: "rgb(250,250,250)"};
  return (
    <div className="programsContainer container" style={style}>
        <Header />
        <Cards />
    </div>
  )
}

export default Programs