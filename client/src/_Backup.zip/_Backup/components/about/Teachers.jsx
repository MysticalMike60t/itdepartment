import React from 'react'
import { Link } from "react-router-dom";
import russell from "../../images/RussellS-150x150.jpg";
import carpenter from "../../images/CarpenterS-150x150.jpg";
import Russell from './Russell';
import Carpenter from './Carpenter';

const Teachers = () => {
  return (
    <>
        <div className="teachers-wrapper">
            <div className="russell inst">
                <div className="teacher">
                    <div className="hover">
                        Steve Russell
                    </div>
                    <img src={russell} alt="" />
                </div>
                <h2>Students</h2>
                <table>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Age</th>
                        <th>Grade<sup>[<Link to="/" className="i">i</Link>]</sup></th>
                    </tr>
                    <Russell />
                </table>
            </div>
            <div className="carpenter inst">
                <div className="teacher">
                    <div className="hover">
                        Mr. Carpenter
                    </div>
                    <img src={carpenter} alt="" />
                </div>
                <h2>Students</h2>
                <table>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Age</th>
                        <th>Grade<sup>[<Link to="/" className="i">i</Link>]</sup></th>
                    </tr>
                    <Carpenter />
                </table>
            </div>
        </div>
    </>
  )
}

export default Teachers