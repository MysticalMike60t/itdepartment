import React from 'react'
import Header from '../Header';
import Teachers from './Teachers';

const about = () => {
    let style = {background: "rgb(250,250,250)"};
  return (
    <div className="aboutContainer container" style={style}>
        <Header />
        <Teachers />
    </div>
  )
}

export default about