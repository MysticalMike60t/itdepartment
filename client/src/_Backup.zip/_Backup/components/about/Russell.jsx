import React from 'react'
import Student from '../../data/components/Student';

const Russell = () => {
  return (
    <>
      <Student firstName="David" lastName="Adams" age="15" grade="9"/>
      <Student firstName="Shaun" lastName="Baker" age="15" grade="9"/>
      <Student firstName="?" lastName="?" age="15" grade="9"/>
      <Student firstName="Luke" lastName="Brink" age="15" grade="9"/>
      <Student firstName="Connor" lastName="Clark" age="15" grade="9"/>
      <Student firstName="Elijah" lastName="Desrosiers-Barry" age="15" grade="9"/>
      <Student firstName="Francisco" lastName="Edmonds-Velez" age="15" grade="9"/>
      <Student firstName="Steven" lastName="Gonzalez" age="15" grade="9"/>
      <Student firstName="Janyia" lastName="Harrigan" age="15" grade="9"/>
      <Student firstName="Xion" lastName="Hines" age="15" grade="9"/>
      <Student firstName="Jessica" lastName="Joseph" age="15" grade="9"/>
      <Student firstName="Dharm" lastName="Mehta" age="15" grade="9"/>
      <Student firstName="Everett" lastName="Mierta" age="15" grade="9"/>
      <Student firstName="Alex" lastName="Murallo" age="15" grade="9"/>
      <Student firstName="Isaiah" lastName="Rivard" age="15" grade="9"/>
      <Student firstName="Achillies" lastName="Rivera" age="15" grade="9"/>
      <Student firstName="Jackson" lastName="Warner" age="15" grade="9"/>
    </>
  )
}

export default Russell