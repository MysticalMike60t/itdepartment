import React from 'react'
import Student from '../../data/components/Student';

const Carpenter = () => {
  return (
    <Student firstName="?" lastName="?" age="?" grade="?"/>
  )
}

export default Carpenter