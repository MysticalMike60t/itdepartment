import React from 'react'

const Contacts = () => {
  let email = "me@grasso.com";
  let link = "mailto:" + email;
  return (
    <div className="info-wrapper">
      <h4>Phone: <span>860-123-4567</span></h4>
      <h4>Email: <a href={link}>{email}</a></h4>
      <h4>Address: <span>My House</span></h4>
    </div>
  )
}

export default Contacts