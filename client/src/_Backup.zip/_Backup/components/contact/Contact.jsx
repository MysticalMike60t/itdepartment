import React from 'react'
import Header from '../Header';
import ContactInfo from './ContactInfo';

const Contact = () => {
  let style = {background: "rgb(250,250,250)"};
  return (
    <div className="contactContainer container" style={style}>
      <Header />
      <ContactInfo />
    </div>
  )
}

export default Contact