import React from 'react';
import './styles/global/uni.scss';
import { Route, Routes } from "react-router-dom";
import Home from './components/home/Home';
import Contact from './components/contact/Contact';
import NoPage from './components/NoPage';
import Programs from './components/programs/Programs';
import About from "./components/about/About";
import Cirs from './components/programs/pages/Cirs';
import Cna from "./components/programs/pages/Cna";
import Cp from "./components/programs/pages/Cp";
import Css from "./components/programs/pages/Css";
import Csa from "./components/programs/pages/Csa";
import Da from "./components/programs/pages/Da";
import Isa from "./components/programs/pages/Isa";
import Ncsa from "./components/programs/pages/Ncsa";
import Sd from "./components/programs/pages/Sd";
import Wd from "./components/programs/pages/Wd";

function App() {
  return (
    <div>
        <Routes>
          <Route path="/">
            <Route index element={<Home />} />
            <Route path="contact" element={<Contact />} />
            <Route path="programs">
              <Route index element={<Programs/>} />
              <Route path="cirs" element={<Cirs/>} />
              <Route path="cna" element={<Cna/>} />
              <Route path="cp" element={<Cp/>} />
              <Route path="css" element={<Css/>} />
              <Route path="csa" element={<Csa/>} />
              <Route path="da" element={<Da/>} />
              <Route path="isa" element={<Isa/>} />
              <Route path="ncsa" element={<Ncsa/>} />
              <Route path="sd" element={<Sd/>} />
              <Route path="wd" element={<Wd/>} />
            </Route>
            <Route path="about" element={<About/>} />
          </Route>
          <Route path="*" element={NoPage} />
        </Routes>
    </div>
  );
}

export default App;
